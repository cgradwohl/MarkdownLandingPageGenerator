var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'crits',
applicationName: 'markdownlandingpage-server',
appUid: 'zYzvghxFcQ1YwbhMz4',
orgUid: 'ssJp7T1f9ZdQn7ZpPp',
deploymentUid: '802f55d7-8df6-4c14-b0f2-a8f1994bb240',
serviceName: 'helloworld',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'helloworld-dev-graphql', timeout: 6}
try {
  const userHandler = require('./dist/graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
