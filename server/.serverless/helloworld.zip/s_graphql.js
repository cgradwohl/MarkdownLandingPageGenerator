
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'crits',
  applicationName: 'markdownlandingpage-server',
  appUid: 'zYzvghxFcQ1YwbhMz4',
  orgUid: 'ssJp7T1f9ZdQn7ZpPp',
  deploymentUid: '7da178fc-5732-4eed-a0b0-d4be25b4553f',
  serviceName: 'helloworld',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'helloworld-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./dist/graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}