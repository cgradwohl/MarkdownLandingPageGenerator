var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'crits',
applicationName: 'markdownlandingpage-server',
appUid: 'zYzvghxFcQ1YwbhMz4',
orgUid: 'ssJp7T1f9ZdQn7ZpPp',
deploymentUid: '8db67ad5-7b47-4d31-9a92-993d5e745e9f',
serviceName: 'helloworld',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'helloworld-dev-graphql', timeout: 6}
try {
  const userHandler = require('./dist/graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
